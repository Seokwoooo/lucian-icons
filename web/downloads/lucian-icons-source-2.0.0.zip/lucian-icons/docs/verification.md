# Verification record

Product path `/icons/`.

## Release 2.0.0 local checks

Date: 2026-10-15. Full redesign: 212 icons (112 kept IDs, 100 new), new runtime, gallery and guide.

- Every icon was drawn on the 24 grid and reviewed in contact sheets at 16/20/24/28/48px in color and line tone, light and dark, plus motion strips of each state transition and hover effect. Fixes found this way include folder skew, envelope folds, fingerprint, handshake, hammer, tree canopy, quote, star start angle, full 360 degree spins for asymmetric icons and the power stem color.
- `npm test`: 14 passed (definitions, exports, skill CLI, build manifest and hashes, page placeholders).
- `tests/browser.mjs` (Chrome, local build): 12 passed. 212 tiles, four per row, visible tiles demo themselves; category, search (Korean typed immediately after opening), `/` shortcut and empty state; language/tone/theme persistence; deep-linked detail dialog with state chips, code tabs, clipboard copy, SVG and HTML downloads, Escape; tile keyboard activation; 25 rapid opposite state changes settle on the last state with no running animations, duplicates independent, reinsertion keeps state; reduced motion runs no animations and stops gallery demos; no horizontal overflow at 320/390/768/1440 on gallery and guide; guide demos drive real element state.
- Bug found by the browser suite and fixed: typing within about 0.6s of opening search placed the caret at the start (the input had zero width while expanding), reversing text.
- axe-core 4.10.3 WCAG 2 A/AA and 2.1 AA: zero violations on the gallery, open detail dialog and guide, light and dark, after raising `--ink-3` contrast and making code blocks keyboard-scrollable.
- Performance: 60fps while scrolling with 12 live demos (average frame 16.6ms).

## Release 1.2.0 local checks

- Exactly 100 additional original definitions, 112 total, grouped into 10 categories. All have unique SVG source, IDs and order, bilingual descriptions/search terms/state labels and matching animated-part baselines.
- All112 were rendered and visually reviewed at 24/32/48/80px in their default and active states. Independent batches inspected forward/reverse motion at0/60/120/220/400ms. Original12 also checked in both themes through800ms. Root inspected every authoring size sheet.
- Existing designs: search, power, mouse and cursor redrawn; bell, heart and bookmark contours refined. Original IDs/states/triggers retained. Trash/folder/envelope/lock/download retain their corrected mechanisms.
- Simultaneous autoplay is independent per preview, starts at90% visibility and stops offscreen. Direct input stops only that preview. Global pause persistence, category/search filtering, inspector, hidden document, reduced motion, delayed-import cancellation and destroy cleanup passed. No demo timers in icon modules or skill exports.
- Node tests:7 passed. Full Chromium acceptance:112 icons,226 supported states,24/32/48px sizes, rapid reversal/remount/duplicates,114 independent HTML executions and474 local asset URLs passed. No page or HTTP errors.
- Independent release review found a P1 static SVG transform-origin mismatch. Reproduced as a failing browser test, fixed by embedding runtime transform-box/origin defaults in every exported part, then checked all226 state renderings for matching live/exported geometry.
- Three automated axe WCAG2 A/AA and2.1 AA scans: zero violations. Category/search/language interaction and both themes/layout widths320/390/768/1440 passed. First viewport module loading is measured by tests/catalog-gallery.py separately from later category browsing.
- Selected-only skill retrieval works for the expanded catalog. Historical1.0.0 and1.1.0 archive URLs remain available. v1.2.0 source/skill archives contain the new drawings and runtime fix.
- Evidence: `.artifacts/batch-*`, `.artifacts/v1.2/existing-before-after.png`, `.artifacts/small-{resting,active}-00.png` through `-09.png`. Public verification follows deployment and is saved separately in `.artifacts/production-verification.json` and `.artifacts/release.json`.

## Release 1.1.0 checks

- Added mouse click and cursor icons, now 12 definitions from the same catalog. New source and skill archives use version 1.1.0; original 1.0.0 archive URLs are preserved.
- Gallery autoplay uses one visible preview at a time, a decorative cursor and click ripple, two synchronized pause controls and a saved preference. Direct input wins. Inspector, hidden-tab, offscreen and reduced-motion checks passed. No autoplay code is included in the runtime or exported icons.
- Download symbols fade out before the next symbol appears. Every pair of its four states, including 48 mid-transition reversals, was sampled at 60fps without overlapping glyphs. Progress contrast was increased for small light-theme previews.
- Envelope opening stages the flap before the letter; the nested viewport clips the letter inside the envelope. Folder skew and protruding lower paper edge were removed. Lock keyhole stays fixed while its shackle opens.
- Captured 98 animation frames before and 98 after the fixes, with forward and reverse contact sheets. Inspected keyframes and all 12 icons at 24/32/48px in both themes. Evidence: `.artifacts/motion-before/`, `.artifacts/motion-after/`, `.artifacts/small-resting.png`, `.artifacts/small-active.png`.
- Node tests: 5 passed. Browser acceptance: 12 icons, all states/sizes, rapid inputs, duplicate instances, remove/reinsert, 14 independent HTML executions, 72 asset URLs, both languages/themes and widths 320/390/768/1440 passed. Zero page errors or HTTP errors.
- WCAG 2 A/AA and 2.1 AA automated scans: zero violations in light gallery, dark gallery and inspector.
- Git-triggered production deployment `dpl_3xt39sXbRfX6Z4GFGqPsr6ThWAG7` reached READY for commit `07cb63b`. Canonical and origin URLs returned version 1.1.0 and all 12 entries. The following documentation and capture-framing commit does not change the application.
- Repeated acceptance, autoplay, interrupted-motion tests and the three automated accessibility scans on the canonical public URL: passed. Captured public desktop/mobile screenshots and frame sheets. Public catalog, all 72 manifest hashes and the downloaded skill search/retrieval flow passed. Original 28 asset hashes, homepage and both UX/UI page titles/statuses remained unchanged; no page errors.
- Existing route version `fc25bc36-185c-4f45-8e7f-8e75cecacd10` is unchanged. Latest deployment metadata and production verification are also recorded in `.artifacts/release.json` and `.artifacts/production-verification.json`.

## Release 1.0.0 baseline

The following production observations were completed for the original release.

## Passed locally

- Node build: 10 definitions, 61 emitted files, catalog and module SHA-256 hashes.
- Node tests: 5 passed. Selected SVG settings, standalone export, scoped embeddable code, CLI search/retrieval/version, refusal to overwrite existing project files.
- Chromium acceptance: all 10 icons, every supported state at 24/32/48 CSS pixels, 60 rapid state changes per icon, opposite state input, invalid attributes, duplicate instances, remove/reinsert.
- Download progress remains progress after 100 percent and a 1.2 second wait; invalid states rejected.
- Keyboard opening and Escape closing of native dialog; focus controls; touch-capable UI without hover.
- Search in Korean and English, no-results state, selected color and size, both themes and languages at widths 320, 390, 768 and 1440 without horizontal overflow.
- Reduced motion disables motion but retains the selected fill and state.
- Clipboard denial produces selected manual-copy text without a success notification.
- Two copied HTML snippets and mixed icon snippets operate independently, including distinct settings. No top-level declaration, CSS or SVG ID collisions.
- Static SVG export preserves selected state, size and palette with no CSS variables or SVG IDs.
- Twelve isolated HTML executions (ten generated plus copied and downloaded selection) have no script imports or external resource requests.
- Promise example: pending, real resolution, real rejection and cancellation follow the actual Promise.
- Both ZIP archives pass zip integrity checks; all 61 local manifest URLs return 200 with correct byte lengths.
- Gallery and inspector page errors: zero. Failed gallery requests: zero.
- axe-core 4.10.3 WCAG 2 A/AA and 2.1 AA scans: zero violations in light gallery, dark gallery and open inspector. This is automated evidence, not a claim of complete accessibility certification.
- Small inspector samples match selected preview background and palette.
- Independent agent applied the installed skill to a separate sample: only download.js, runtime.js and LICENSE retrieved; 12 checks passed including 48 repeat inputs producing one pending request, keyboard/touch, themes, cancellation and reconnect.
- Independent release review: no P0/P1 findings. One P2 sample-background mismatch was reproduced, fixed and covered by a passing regression.

## Visual evidence

Screenshots in `.artifacts/`: desktop.png, desktop-full.png, desktop-dark-en.png, mobile.png, mobile-full.png, mobile-dark-en.png, detail.png, mobile-detail.png, all-resting.png and all-active.png. The desktop, mobile, theme and inspector screenshots were recaptured from https://lucianlabs.dev/icons/ after deployment. all-resting.png and all-active.png are local runtime comparison fixtures. Reference browser screenshots are stored separately in /workspace/scratch/reference/.

## Production observations

- https://lucianlabs.dev/ -> 200, correct lucianLabs title, no page error.
- https://lucianlabs.dev/uxui-prompt/ -> 200, correct gallery title, no page error.
- https://lucianlabs.dev/uxui-prompt/introducing/ -> 200, correct introduction title, no page error.
- https://lucianlabs.dev/icons/ -> 200, correct product title and version, browser acceptance passed. `/icons` redirects to `/icons/`; a missing icon asset returns 404.
- All 61 public manifest URLs return 200 and match both byte length and SHA-256. Skill and source ZIP downloads are valid. Downloaded skill searches Korean, retrieves only download.js/runtime.js/LICENSE and reports version 1.0.0.
- Origin and canonical URL acceptance: all ten states/sizes/reversal/duplicate cases, 12 isolated HTML documents, real Promise outcomes, keyboard, reduced motion, both languages/themes and 320/390/768/1440 widths passed. Additional mobile touch context passed.
- Public automated accessibility scan: zero WCAG 2 A/AA and 2.1 AA violations in light, dark and inspector views. No gallery console errors or failed requests.
- Existing root and both UX/UI pages retain their titles and return 200 without page errors. 28 existing assets have exactly the same hashes as before the route addition.
- Existing production deployment was preserved. Only two scoped project-level rules were added for /icons. No DNS or protection settings changed. See deployment.md.

## Limits

- Public GitHub visibility. Creation was initially denied by the integration; the user then created Seokwoooo/lucian-icons privately. Write access is available. Private visibility is retained pending explicit approval for that settings change.
- Direct file:// navigation: Chromium administrator policy returns ERR_BLOCKED_BY_ADMINISTRATOR. Exact downloaded HTML contents were instead loaded into fresh about:blank pages and verified with no network resources. File:// behavior is not claimed as executed.
- Actual installed Claude Code or Codex native runtime invocation. Documentation verified from official sources, CLI/package tested and a separate agent performed a skill-guided sample integration.
- Safari/WebKit, Firefox, physical mobile devices and screen-reader manual audits.

## Re-run

Start `python -m http.server 4173 -d dist`, then:

```
npm test
python tests/runtime.py
python tests/gallery.py
python tests/acceptance.py
python tests/copy-collision.py
python tests/preview-theme.py
```

For hosted acceptance set `TEST_URL=https://your-host/icons/` for gallery.py and acceptance.py. The copy-collision and preview-theme regression scripts currently target the local preview.
